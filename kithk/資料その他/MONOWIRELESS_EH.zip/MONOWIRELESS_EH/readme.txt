Mono Wireless Energy Harvesting Demo Software:
For more detail please visit our web site: MONO-WIRELESS.COM
Please enjoy with energy harvesting!

[NOTICE]
- Mono Wireless Inc. does not have any liablity; such as damage; in use of this software.
- This software (including built binary and source codes) can be used only with Mono Wireless Engine.
- As long as using with Mono Wireless Engine, you can modify this software.
- Do not distribute to third party without permission of Mono Wireless.
- This software is distributed for evaluation purpose, therefore,
- Mono Wireless does not privide any of support.
-- EOL --
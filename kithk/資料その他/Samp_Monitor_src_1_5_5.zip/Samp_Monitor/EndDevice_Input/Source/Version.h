// now CFLAGS option is used instead of updating version.h (SDK2014/03)
